System Dashboard update v6
==========================

This update is based on v5 and changes only the Local AI message rendering/paging and adds an online safe-rated anime wallpaper browser.

Files to replace
----------------
1. system-dashboard/app.py
2. system-dashboard/templates/dashboard.html

Back up both files before replacing them. Stop the existing dashboard service, copy the two files into the same paths in ~/system-dashboard, then restart the same service and hard-refresh the browser (Ctrl+Shift+R).

Example backup:
  cp ~/system-dashboard/app.py ~/system-dashboard/app.py.before-v6
  cp ~/system-dashboard/templates/dashboard.html ~/system-dashboard/templates/dashboard.html.before-v6

Online wallpapers
-----------------
The Wallpapers tab now has a Search online button. It queries the safe-rated Konachan.net endpoint only, shows low-quality previews, supports tag suggestions, opens a larger preview, and saves a selected image directly into ~/Pictures/Wallpapers on the dashboard host. It does not send the file to the browser's Downloads folder. Only results marked safe by the source API are returned and the server rechecks the rating before saving. Ratings depend on source tagging and are not a guarantee that every image is suitable.

Local AI
--------
- User names are resolved to display names and profile pictures from the dashboard's member/profile data.
- Profile picture/name controls in Ollama Chat are wired to open the corresponding dashboard profile.
- Ollama Chat now expands its visible history in ten-message increments when scrolling to the top and preserves the reading position, following the General chat pattern. The Older/Newer controls use the same expanding-history model.

Validation performed
--------------------
- Python syntax compilation passed.
- Jinja template parse passed.
- All inline JavaScript blocks passed Node syntax checks.
- No live Flask/browser test was possible in the build environment, so test the new endpoints after restarting your local dashboard. Keep the backups available for rollback.
